#ifndef __GUI_H
#define __GUI_H 	
#include "system.h"


#include "button.h"
#include "listbox.h"
#include "scrollbar.h"
#include "progressbar.h"
#include "filelistbox.h"
#include "edit.h"
#include "memo.h"
#include "window.h"


#endif




























#include "system.h"
#include "SysTick.h"
#include "led.h"



int main()
{
	SysTick_Init(72);
	LED_Init();
	while(1)
	{
		LED1=0;
		LED2=1;
		delay_ms(500);  //��ȷ��ʱ500ms
		LED1=1;
		LED2=0;
		delay_ms(500);  //��ȷ��ʱ500ms
	}
}

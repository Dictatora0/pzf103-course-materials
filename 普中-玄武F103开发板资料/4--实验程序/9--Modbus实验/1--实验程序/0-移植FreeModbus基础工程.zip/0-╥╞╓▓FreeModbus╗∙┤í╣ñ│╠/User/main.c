#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "usart.h"
#include "key.h"
#include "rs485.h"


int main()
{
	u8 i=0;
	u8 rs485buf[5];
	u8 len=0;
	u8 key=0;
	
	SysTick_Init(72);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�ж����ȼ����� ��2��
	LED_Init();
	USART1_Init(115200);
	KEY_Init();
	RS485_Init(9600);
	
	while(1)
	{
		key=KEY_Scan(0);
		if(key==KEY_UP_PRESS)
		{
			RS485_Send_Data(rs485buf,5);
		}
		RS485_Receive_Data(rs485buf,&len);
		
		i++;
		if(i%20==0)
		{
			LED1=!LED1;
		}		
		delay_ms(10);
	}
}

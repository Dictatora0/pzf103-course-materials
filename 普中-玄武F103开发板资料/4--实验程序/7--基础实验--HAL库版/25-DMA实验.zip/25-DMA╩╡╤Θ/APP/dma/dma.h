#ifndef _dma_H
#define _dma_H

#include "system.h"

extern DMA_HandleTypeDef  UART1TxDMA_Handler;      //DMA���


void DMAx_Init(DMA_Channel_TypeDef *chx);
void DMAx_USART_Transmit(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size);


#endif

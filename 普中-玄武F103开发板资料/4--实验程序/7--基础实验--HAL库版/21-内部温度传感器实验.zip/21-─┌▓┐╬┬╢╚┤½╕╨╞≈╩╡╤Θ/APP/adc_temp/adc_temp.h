#ifndef _adc_temp_H
#define _adc_temp_H

#include "system.h"

void ADC_Temp_Init(void);
int Get_Temperture(void);

#endif

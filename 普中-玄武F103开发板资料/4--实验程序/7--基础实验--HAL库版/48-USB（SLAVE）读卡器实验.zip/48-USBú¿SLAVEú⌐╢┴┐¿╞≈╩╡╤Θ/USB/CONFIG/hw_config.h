#ifndef __HWCONFIG_H
#define __HWCONFIG_H
#include <stdint.h>
#include "system.h"


void Error_Handler(void);

void USB_Reset(void);
uint8_t USB_GetStatus(void);

#endif


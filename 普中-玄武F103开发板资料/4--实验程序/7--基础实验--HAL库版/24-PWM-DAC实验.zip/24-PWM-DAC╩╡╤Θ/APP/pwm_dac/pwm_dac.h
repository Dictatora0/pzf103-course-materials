#ifndef _pwm_dac_H
#define _pwm_dac_H

#include "system.h"


void TIM1_CH1_PWM_Init(u16 arr,u16 psc);
void TIM_SetTIM1Compare1(u32 compare);
u32 TIM_GetTIM1CompareValue(u32 Channel);

#endif


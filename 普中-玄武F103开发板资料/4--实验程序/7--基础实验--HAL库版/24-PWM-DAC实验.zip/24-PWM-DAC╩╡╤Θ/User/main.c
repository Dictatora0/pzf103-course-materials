#include "system.h"
#include "SysTick.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "adc.h"
#include "pwm_dac.h"


/*******************************************************************************
* �� �� ��         : main
* ��������		   : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
int main()
{
	u8 i=0;
	u8 key;
	int pwm_value=0;
	u8 pwmval;
	u16 adc_value;
	float adc_vol;
	float pwm_vol;
	
	HAL_Init();                     //��ʼ��HAL�� 
	SystemClock_Init(RCC_PLL_MUL9); //����ʱ��,72M
	SysTick_Init(72);
	USART1_Init(115200);
	LED_Init();
	KEY_Init();
	ADCx_Init();
	TIM1_CH1_PWM_Init(255,0);       //TIM1 PWM��ʼ��, Fpwm=72M/256=281.25Khz

	while(1)
	{
		key=KEY_Scan(0);
		if(key==KEY_UP_PRESS)
		{
			pwm_value+=10;
			if(pwm_value>=250)
			{
				pwm_value=255;	
			}
			TIM_SetTIM1Compare1(pwm_value);
		}
		else if(key==KEY0_PRESS)
		{
			pwm_value-=10;
			if(pwm_value<10)
			{
				pwm_value=0;	
			}
			TIM_SetTIM1Compare1(pwm_value);		
		}
		
		i++;
		if(i%20==0)
		{
			LED1=!LED1;
		}
		
		if(i%50==0)
		{
			pwmval=TIM_GetTIM1CompareValue(TIM_CHANNEL_1);
			pwm_vol=(float)pwmval*(3.3/256);
			printf("PWM�����ѹΪ��%.3fV\r\n",pwm_vol);
			
			
			adc_value=Get_ADC_Value(ADC_CHANNEL_1,20);
			adc_vol=(float)adc_value*(3.3/4096);
			printf("ADC����ѹΪ��%.3fV\r\n",adc_vol);
		}
		delay_ms(10);
	}
}

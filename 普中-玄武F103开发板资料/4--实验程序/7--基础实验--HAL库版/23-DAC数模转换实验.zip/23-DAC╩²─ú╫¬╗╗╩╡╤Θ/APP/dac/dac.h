#ifndef _dac_H
#define _dac_H

#include "system.h"



void DAC1_Init(void);		//DACͨ��1��ʼ��	 	 
void DAC1_Set_Vol(u16 vol);
u32 DAC1_GetValue(void);

#endif

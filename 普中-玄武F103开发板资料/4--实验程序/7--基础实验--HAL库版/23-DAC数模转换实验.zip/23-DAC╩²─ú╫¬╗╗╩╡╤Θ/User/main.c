#include "system.h"
#include "SysTick.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "dac.h"


/*******************************************************************************
* �� �� ��         : main
* ��������		   : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
int main()
{
	u8 i=0;
	u8 key;
	int dac_value=0;
	u16 dacval;
	float dac_vol;
	
	HAL_Init();                     //��ʼ��HAL�� 
	SystemClock_Init(RCC_PLL_MUL9); //����ʱ��,72M
	SysTick_Init(72);
	USART1_Init(115200);
	LED_Init();
	KEY_Init();
	DAC1_Init();

	while(1)
	{
		key=KEY_Scan(0);
		if(key==KEY_UP_PRESS)
		{
			dac_value+=330;
			if(dac_value>=3300)
			{
				dac_value=3300;
			}
			DAC1_Set_Vol(dac_value);
		}
		else if(key==KEY0_PRESS)
		{
			dac_value-=330;	
			if(dac_value<=0)
			{
				dac_value=0;
			}
			DAC1_Set_Vol(dac_value);		
		}
		
		i++;
		if(i%20==0)
		{
			LED1=!LED1;
		}
		
		if(i%50==0)
		{
			dacval=DAC1_GetValue();
			dac_vol=(float)dacval*(3.3/4096);
			printf("���DAC��ѹֵΪ��%.2fV\r\n",dac_vol);
		}
		delay_ms(10);
	}
}

#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "usart.h"
#include "tftlcd.h"
#include "key.h"
#include "malloc.h" 
#include "sdio_sdcard.h"
#include "flash.h"
#include "ff.h" 
#include "fatfs_app.h"
#include "font_show.h"
#include "vs10xx.h"
#include "recorder.h"	


int main()
{
	SysTick_Init(168);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�ж����ȼ����� ��2��
	LED_Init();
	USART1_Init(115200);
	TFTLCD_Init();			//LCD��ʼ��
	KEY_Init();
	EN25QXX_Init();	
	VS_Init();	  				//��ʼ��VS1053	
	my_mem_init(SRAMIN);		//��ʼ���ڲ��ڴ��
	FATFS_Init();				//Ϊfatfs��ر��������ڴ�				 
  	f_mount(fs[0],"0:",1); 		//����SD��
	f_mount(fs[1],"1:",1); 		//����SPI FLASH
	FRONT_COLOR=RED; 
	while(font_init()) 		        //����ֿ�
	{  
		LCD_ShowString(10,10,tftlcd_data.width,tftlcd_data.height,16,"Font Error!   ");
		delay_ms(500);
	} 
	LCD_ShowFontString(10,10,tftlcd_data.width,tftlcd_data.height,"���пƼ�-PRECHIN",16,0);
	LCD_ShowFontString(10,30,tftlcd_data.width,tftlcd_data.height,"www.prechin.net",16,0);
	LCD_ShowFontString(10,50,tftlcd_data.width,tftlcd_data.height,"WAV¼����ʵ��",16,0);
	LCD_ShowFontString(10,70,tftlcd_data.width,tftlcd_data.height,"KEY0:REC/PAUSE",16,0);
	LCD_ShowFontString(10,90,tftlcd_data.width,tftlcd_data.height,"KEY1:STOP&SAVE",16,0);
	LCD_ShowFontString(10,110,tftlcd_data.width,tftlcd_data.height,"KEY_UP:AGC+  ",16,0);
	LCD_ShowFontString(10,130,tftlcd_data.width,tftlcd_data.height,"KEY2:Play The File",16,0);
	
	while(1)
	{
		LED2=0; 	  
		LCD_ShowFontString(10,160,tftlcd_data.width,tftlcd_data.height,"�洢������...",16,0);
		printf("Ram Test:0X%04X\r\n",VS_Ram_Test());//��ӡRAM���Խ��	    
		LCD_ShowFontString(10,160,tftlcd_data.width,tftlcd_data.height,"���Ҳ�����...",16,0); 	 	 
 		VS_Sine_Test();	  
		LCD_Fill(10,160,240,176,WHITE);
		LED2=1;
		recoder_play();
	}
}

#ifndef _hc05_H
#define _hc05_H	

#include "system.h" 


#define HC05_KEY  	PAout(4) 		//��������KEY�ź�
#define HC05_LED  	PAin(15)		//��������״̬�ź�

typedef struct{
	volatile char namebuff[30];
	volatile char addrbuff[30];
	volatile char versionbuff[30];
	uint8_t flag;
}TypeBt11;

extern uint32_t test_flag;

u8 HC05_Init(void);
void Bt11_Test(void);
void rea(void);
u8 HC05_Get_Role(void);
u8 HC05_Set_Cmd(u8* atstr);	

#endif  

















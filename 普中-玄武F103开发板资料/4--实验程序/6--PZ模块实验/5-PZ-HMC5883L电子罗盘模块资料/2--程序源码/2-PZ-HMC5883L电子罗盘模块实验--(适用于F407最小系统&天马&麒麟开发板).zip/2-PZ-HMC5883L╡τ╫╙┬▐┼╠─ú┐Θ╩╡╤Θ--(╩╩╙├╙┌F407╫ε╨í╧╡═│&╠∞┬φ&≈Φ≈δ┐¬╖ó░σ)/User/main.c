#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "usart.h"
#include "key.h"
#include "qmc5883.h"
#include "hmc5883l.h"


//��ȡ���̷�λ
void Get_Position(float angle)
{
	if((angle < 22.5) || (angle > 337.5 ))
		printf("��(South)\r\n");
	if((angle > 22.5) && (angle < 67.5 ))
		printf("����(SouthWest)\r\n");
	if((angle > 67.5) && (angle < 112.5 ))
		printf("��(West)\r\n");
	if((angle > 112.5) && (angle < 157.5 ))
		printf("����(NorthWest)\r\n");
	if((angle > 157.5) && (angle < 202.5 ))
		printf("��(North)\r\n");
	if((angle > 202.5) && (angle < 247.5 ))
		printf("����(NorthEast)\r\n");
	if((angle > 247.5) && (angle < 292.5 ))
		printf("��(East)\r\n");
	if((angle > 292.5) && (angle < 337.5 ))
		printf("����(SouthEast)\r\n");
}

int main()
{
	u8 i=0;
	float xy_angle;
	
	SysTick_Init(168);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //�ж����ȼ����� ��2��
	LED_Init();
	USART1_Init(115200);
	KEY_Init();
	QMC5883L_Init();
	
	while(1)
	{
		xy_angle=QMC5883L_Read_Angle();
		i++;
		if(i%20==0)
		{
			LED1=!LED1;
		}
		if(i%50==0)
		{
			printf("xy_angle=%0.1f\r\n",xy_angle);
			Get_Position(xy_angle);
		}
		delay_ms(10);
	}
}

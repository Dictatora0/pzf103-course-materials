#include "lv_ta_test.h"
#include "lvgl.h"
#include "key.h"
#include <stdio.h>
#include <string.h>

lv_obj_t * ta1;

//事件回调函数
void event_handler(lv_obj_t *obj,lv_event_t event)
{
  if(event==LV_EVENT_VALUE_CHANGED)//文本内容改变时,就会触发此事件
  {
    printf("LV_EVENT_VALUE_CHANGED:%s\r\n",lv_ta_get_text(ta1));//把当前的文本打印出来
  }else if(event==LV_EVENT_INSERT)//有文本插入时,就会触发此事件
  {
    const char * inserted_txt = lv_event_get_data();//获取被插入的文本
    printf("LV_EVENT_INSERT:%s\r\n",inserted_txt);//把插入的文本打印出来
    if(strcmp(inserted_txt,"d")==0)//如果插入的是d字符串的话,就进行过滤或者格式控制
    {
      lv_ta_set_insert_replace(ta1,"2019/12/26");//用"2019/12/26"替换掉正准备插入的"d"
    }
  }
}

//例程入口
void lv_ta_test_start()
{
	lv_obj_t *scr = lv_scr_act();//获取当前活跃的屏幕对象

  //1.创建文本域对象
  ta1 = lv_ta_create(scr,NULL);
  lv_obj_set_size(ta1,200,100);//设置文本域的大小
  lv_obj_align(ta1,NULL,LV_ALIGN_CENTER,0,0);//与屏幕居中对齐
  lv_ta_set_cursor_type(ta1,LV_CURSOR_LINE);//设置光标的类型为竖直线
  lv_ta_set_placeholder_text(ta1,"Please input");//设置提示文字,当文本内容为空时,才会显示出来
  lv_ta_set_text(ta1,"This is a text area!");//设置文本内容
  lv_ta_set_pwd_mode(ta1,false);//不使能密码保护模式,默认就是不使能的
  lv_ta_set_one_line(ta1,false);//不使能单行模式,默认就是不使能的
  lv_ta_set_text_sel(ta1,true);//使能文本选中功能
  lv_ta_set_cursor_click_pos(ta1,true);//使能用户点击改变光标位置,默认就是使能的
  lv_ta_set_text_align(ta1,LV_LABEL_ALIGN_LEFT);//设置文本居左对齐,默认就是居左对齐
  lv_obj_set_event_cb(ta1,event_handler);//设置事件回调函数
  
}


//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		//往光标所在的位置处添加文本
		lv_ta_add_text(ta1,"[add txt]");
	}else if(key==KEY1_PRESS)
	{
		//删除光标左侧的一个字符
		lv_ta_del_char(ta1);
	}else if(key==KEY_UP_PRESS)
	{
		//往光标所在的位置处添加字符,用来演示插入替换功能
		lv_ta_add_char(ta1,'d');
	}
}


#ifndef __LV_LED_TEST_H__
#define __LV_LED_TEST_H__
#include "system.h"





//��������
void lv_led_test_start(void);
void key_handler(void);
#endif



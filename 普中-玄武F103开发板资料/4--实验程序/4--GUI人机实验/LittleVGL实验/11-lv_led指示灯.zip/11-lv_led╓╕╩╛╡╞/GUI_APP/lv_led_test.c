#include "lv_led_test.h"
#include "lvgl.h"
#include "key.h"


lv_obj_t * led1,* led2;
int16_t led2_bright = 190;//先给个默认亮度

//例程入口函数
void lv_led_test_start()
{
	lv_obj_t* scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建指示灯的样式
	static lv_style_t led_style;
	lv_style_copy(&led_style, &lv_style_pretty_color);//样式拷贝
	led_style.body.radius = LV_RADIUS_CIRCLE;//绘制半圆角
	led_style.body.main_color = LV_COLOR_MAKE(0xb5, 0x0f, 0x04);//主背景的上半部分的颜色
	led_style.body.grad_color = LV_COLOR_MAKE(0x50, 0x07, 0x02);//主背景的下半部分的颜色
	led_style.body.border.color = LV_COLOR_MAKE(0xfa, 0x0f, 0x00);//边框颜色
	led_style.body.border.width = 3;//边框的宽度
	led_style.body.border.opa = LV_OPA_30;//透明度
	led_style.body.shadow.color = LV_COLOR_MAKE(0xb5, 0x0f, 0x04);//阴影的颜色
	led_style.body.shadow.width = 5;//阴影的大小

	//2.创建LED1,并设置其默认为OFF状态
	led1 = lv_led_create(scr, NULL);
	lv_obj_set_pos(led1,50,50);//设置坐标
	lv_obj_set_size(led1,30,30);//设置大小
	lv_obj_set_style(led1, &led_style);//设置样式
	lv_led_off(led1);

	//3.创建LED2,先直接从LED1拷贝过来
	led2  = lv_led_create(scr, led1);
	lv_obj_align(led2,led1,LV_ALIGN_OUT_BOTTOM_MID,0,40);//设置对齐方式
	lv_led_set_bright(led2, led2_bright);//设置亮度值
}

//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);

	if(key==KEY0_PRESS)
	{
		//来回切换LED1的状态
		lv_led_toggle(led1);
	}else if(key==KEY1_PRESS)
	{
		//增加LED2的亮度
		led2_bright += 20;
		if(led2_bright>255)
			led2_bright = 0;
			
		lv_led_set_bright(led2, led2_bright);
	}else if(key==KEY2_PRESS)
	{
		//减少LED2的亮度
		led2_bright -= 20;
		if(led2_bright<0)
			led2_bright = 255;
		
		lv_led_set_bright(led2, led2_bright);
	}
}


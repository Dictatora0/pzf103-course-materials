#include "lv_bar_test.h"
#include "lvgl.h"


lv_style_t bar_bg_style;//进度条的背景样式
lv_style_t bar_indic_style;//进度条的指示器样式


//例程入口
void lv_bar_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建进度条的背景和指示器样式
	//1.1 创建背景样式
	lv_style_copy(&bar_bg_style,&lv_style_plain_color);
	bar_bg_style.body.main_color = LV_COLOR_MAKE(0xBB,0xBB,0xBB);
	bar_bg_style.body.grad_color = LV_COLOR_MAKE(0xBB,0xBB,0xBB);
	bar_bg_style.body.radius = LV_RADIUS_CIRCLE;//绘制圆角
	//1.2 创建指示器样式
	lv_style_copy(&bar_indic_style,&lv_style_plain_color);
	bar_indic_style.body.main_color = LV_COLOR_MAKE(0x5F,0xB8,0x78);
	bar_indic_style.body.grad_color = LV_COLOR_MAKE(0x5F,0xB8,0x78);
	bar_indic_style.body.radius = LV_RADIUS_CIRCLE;//绘制圆角
	bar_indic_style.body.padding.left = 0;//让指示器跟背景边框之间没有距离
	bar_indic_style.body.padding.top = 0;
	bar_indic_style.body.padding.right = 0;
	bar_indic_style.body.padding.bottom = 0;
	

	//2.创建水平进度条
	lv_obj_t * bar1 = lv_bar_create(scr, NULL);//创建进度条
	lv_obj_set_size(bar1,180,16);//设置大小,宽度比高度大就是水平的
	lv_obj_set_pos(bar1,20,20);//设置坐标
	lv_bar_set_style(bar1,LV_BAR_STYLE_BG,&bar_bg_style);//设置进度条背景的样式
	lv_bar_set_style(bar1,LV_BAR_STYLE_INDIC,&bar_indic_style);//设置进度条指示器的样式
	lv_bar_set_anim_time(bar1,1000);//设置动画时长
	lv_bar_set_value(bar1,100,LV_ANIM_ON);//设置新的进度值,带有动画效果的

	//3.创建垂直进度条
	lv_obj_t * bar2 = lv_bar_create(scr, bar1);//从bar1进行拷贝
	lv_obj_set_size(bar2,16,180);//设置大小,宽度比高度小就是垂直的
	lv_obj_align(bar2,bar1,LV_ALIGN_OUT_BOTTOM_LEFT,0,10);//设置与bar1的对齐方式
	lv_bar_set_range(bar2,100,200);//设置进度范围
	lv_bar_set_anim_time(bar2,1000);//设置动画时长
	lv_bar_set_value(bar2,180,LV_ANIM_ON);//设置新的进度值,180正好是80%的进度
}

#include "lv_slider_test.h"
#include "lvgl.h"
#include <stdio.h>

lv_style_t slider_bg_style;//背景的样式
lv_style_t slider_indic_style;//指示器的样式
lv_style_t slider_knob_style;//旋钮的样式

lv_obj_t * label1;

//事件回调函数
static void event_handler(lv_obj_t * obj,lv_event_t event)
{
	char buff[16];
	if(event==LV_EVENT_VALUE_CHANGED||event == LV_EVENT_RELEASED)//lv_slider的进度值发生了改变或者松手了
	{
		//将当前的进度显示在label1标签中,如果是松手事件的话,则加上"End:"前缀
		sprintf(buff,event==LV_EVENT_VALUE_CHANGED?"%d%%":"End:%d%%",lv_slider_get_value(obj));
		lv_label_set_text(label1,buff);
		lv_obj_realign(label1);
	}
}

//例程入口
void lv_slider_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建用于滑块的3个样式
	//1.1 创建背景样式
	lv_style_copy(&slider_bg_style,&lv_style_pretty);
	slider_bg_style.body.main_color = LV_COLOR_BLACK;
	slider_bg_style.body.grad_color = LV_COLOR_GRAY;
	slider_bg_style.body.radius = LV_RADIUS_CIRCLE;
	slider_bg_style.body.border.color = LV_COLOR_WHITE;
	//1.2 创建指示器的样式
	lv_style_copy(&slider_indic_style,&lv_style_pretty_color);
	slider_indic_style.body.main_color = LV_COLOR_MAKE(0x5F,0xB8,0x78);
	slider_indic_style.body.grad_color = LV_COLOR_MAKE(0x5F,0xB8,0x78);
	slider_indic_style.body.radius = LV_RADIUS_CIRCLE;
	slider_indic_style.body.shadow.width = 8;
	slider_indic_style.body.shadow.color = slider_indic_style.body.main_color;
	slider_indic_style.body.padding.left = 3;//设置指示器与背景边框之间的距离
	slider_indic_style.body.padding.right = 3;
	slider_indic_style.body.padding.top = 3;
	slider_indic_style.body.padding.bottom = 3;
	//1.3 创建旋钮的样式
	lv_style_copy(&slider_knob_style,&lv_style_pretty);
	slider_knob_style.body.radius = LV_RADIUS_CIRCLE;
	slider_knob_style.body.opa = LV_OPA_70;

	//2.创建滑块对象
	lv_obj_t * slider1 = lv_slider_create(scr,NULL);
	lv_obj_set_size(slider1,200,20);//设置大小,当宽度比高度大时,是水平滑块,当宽度比高度小时,是垂直滑块
	lv_slider_set_range(slider1,0,100);//设置进度范围
	lv_slider_set_anim_time(slider1,1000);//设置动画时长,必须得放在lv_slider_set_value前面调用,否则无效
	lv_slider_set_value(slider1,70,LV_ANIM_ON);//设置当前的进度值,使能动画效果
	lv_slider_set_style(slider1,LV_SLIDER_STYLE_BG,&slider_bg_style);//设置背景样式
	lv_slider_set_style(slider1,LV_SLIDER_STYLE_INDIC,&slider_indic_style);//设置指示器的样式
	lv_slider_set_style(slider1,LV_SLIDER_STYLE_KNOB,&slider_knob_style);//设置旋钮的样式
	lv_obj_align(slider1,NULL,LV_ALIGN_CENTER,0,0);//设置与屏幕居中对齐
	lv_obj_set_event_cb(slider1,event_handler);//设置事件

	//3.创建标签,用来显示滑块的当前进度
	label1 = lv_label_create(scr,NULL);
	lv_obj_align(label1,slider1,LV_ALIGN_OUT_TOP_MID,0,-10);
	lv_label_set_text(label1,"70%");
}




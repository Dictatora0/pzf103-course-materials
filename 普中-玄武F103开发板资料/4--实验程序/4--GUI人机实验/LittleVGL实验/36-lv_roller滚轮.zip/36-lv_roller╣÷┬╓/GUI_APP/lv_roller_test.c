#include "lv_roller_test.h"
#include "lvgl.h"
#include <stdio.h>


lv_style_t bg_style;
lv_style_t sel_style;


//事件回调函数
void event_handler(lv_obj_t * obj,lv_event_t event)
{
	char txt[32];
	if(event==LV_EVENT_VALUE_CHANGED)
	{
		lv_roller_get_selected_str(obj,txt,sizeof(txt));
		printf("Selected text: %s\r\n",txt);
	}
}

//例程入口
void lv_roller_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建样式
	//1.1 创建背景样式
	lv_style_copy(&bg_style,&lv_style_plain);
	bg_style.body.main_color = LV_COLOR_WHITE;//纯白色背景
	bg_style.body.grad_color = bg_style.body.main_color;
	bg_style.body.border.width = 1;//边框宽度
	bg_style.body.border.color = LV_COLOR_MAKE(0xAA,0xAA,0xAA);//LV_COLOR_MAKE(0x30,0x30,0x30);//边框颜色
	bg_style.body.padding.left = 10;//设置左侧的内边距
	bg_style.text.color = LV_COLOR_BLACK;//文本颜色
	bg_style.body.shadow.color = bg_style.body.border.color;//阴影颜色
	bg_style.body.shadow.width = 4;//阴影宽度
	//1.2 创建选择项被选中时的样式
	lv_style_copy(&sel_style,&lv_style_plain);
	sel_style.body.main_color = LV_COLOR_MAKE(0x5F,0xB8,0x78);//浅绿色背景
	sel_style.body.grad_color = sel_style.body.main_color;
	sel_style.text.color = LV_COLOR_WHITE;//文本为白色

	//2.创建滚轮对象
	lv_obj_t * roller1 = lv_roller_create(scr,NULL);
	lv_roller_set_options(roller1,"Shanghai\nBeijing\nShenzhen\nGuangzhou\nHangzhou\nNanchang",LV_ROLLER_MODE_INIFINITE);//设置所有的选项值,循环滚动模式
	lv_roller_set_selected(roller1,3,LV_ANIM_OFF);//设置默认选中值为Guangzhou
	lv_roller_set_fix_width(roller1,140);//设置固定宽度
	lv_roller_set_visible_row_count(roller1,4);//设置可见的行数
	lv_roller_set_style(roller1,LV_ROLLER_STYLE_BG,&bg_style);//设置背景样式
	lv_roller_set_style(roller1,LV_ROLLER_STYLE_SEL,&sel_style);//设置背景样式
	lv_obj_set_event_cb(roller1,event_handler);//注册事件回调函数
	lv_obj_align(roller1,NULL,LV_ALIGN_CENTER,0,0);//设置与屏幕居中对齐
}


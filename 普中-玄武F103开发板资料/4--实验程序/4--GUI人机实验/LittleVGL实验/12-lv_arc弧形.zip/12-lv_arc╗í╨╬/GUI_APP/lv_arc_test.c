#include "lv_arc_test.h"
#include "lvgl.h"
#include "key.h"
#include <stdio.h>


lv_style_t arc_style;
lv_obj_t * arc3;
lv_obj_t * progress_label;
uint8_t progress = 0;//当前的进度,范围[0,100]
uint8_t is_pause = 0;//是否暂停加载过程

//弧形3设置进度
//progress:进度值,范围为[0,100]
static void arc3_set_progress(uint8_t progress)
{
	char buff[10];
	lv_arc_set_angles(arc3,0,(uint16_t)(3.6f*progress));

	sprintf(buff,"%d%%",progress);
	lv_label_set_text(progress_label,buff);
	lv_obj_realign(progress_label);//重新与arc3居中对齐
}

//任务回调函数
static void progress_task(lv_task_t * t)
{
	if(is_pause)
		return;
	progress++;
	if(progress>100)
		 progress = 0;
	arc3_set_progress(progress);
}


//例程入口
void lv_arc_test_start()
{
    lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

    //1.先创建1个样式
    lv_style_copy(&arc_style, &lv_style_plain);
    arc_style.line.color = LV_COLOR_RED; //弧形的颜色
    arc_style.line.width = 8; //弧形的厚度
    arc_style.line.rounded = 1;//末端为圆角,如果为0的话,则为直角

    //2.创建弧形1(让终止角度比起始角度小)
    lv_obj_t * arc1 = lv_arc_create(scr, NULL);//创建弧形对象
    lv_arc_set_style(arc1, LV_ARC_STYLE_MAIN, &arc_style); //设置样式
    lv_arc_set_angles(arc1, 180, 90);//设置角度
    lv_obj_set_size(arc1, 100, 100);//设置大小,设置的宽度和高度必须得相等,弧形半径等于宽度的一半
    lv_obj_set_pos(arc1,20,20);//设置坐标

    //3.创建弧形2(让终止角度比起始角度大)
    lv_obj_t * arc2 = lv_arc_create(scr, arc1);//直接从arc1拷贝
    lv_obj_align(arc2,arc1,LV_ALIGN_OUT_RIGHT_TOP,10,0);//设置与arc1的对齐方式
    lv_arc_set_angles(arc2, 90, 180);//设置角度

    //4.创建弧形3,实现环形进度条的效果
    //4.1 创建弧形3
    arc3 = lv_arc_create(scr, arc1);//直接从arc1拷贝
    lv_obj_align(arc3,arc1,LV_ALIGN_OUT_BOTTOM_LEFT,0,10);//设置与arc1的对齐方式
    //4.2 创建进度指示label
    progress_label = lv_label_create(scr,NULL);
    lv_obj_align(progress_label,arc3,LV_ALIGN_CENTER,0,0);//与arc3居中对齐
    //4.3 设置一个默认的进度值
    arc3_set_progress(progress);
    //4.4 创建一个任务来模拟进度的加载过程
    lv_task_create(progress_task,200,LV_TASK_PRIO_MID,NULL);
}

//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		is_pause = !is_pause;
	}
}

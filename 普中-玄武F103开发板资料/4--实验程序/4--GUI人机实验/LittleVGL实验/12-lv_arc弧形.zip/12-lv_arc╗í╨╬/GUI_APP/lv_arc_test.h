#ifndef __LV_ARC_TEST_H__
#define __LV_ARC_TEST_H__
#include "system.h"





//��������
void lv_arc_test_start(void);
void key_handler(void);
#endif



#include "lv_img_test.h"
#include "lvgl.h"
#include "key.h"


lv_style_t img_style;

//图片申明
LV_IMG_DECLARE(true_color);
LV_IMG_DECLARE(true_color_with_alpha);
LV_IMG_DECLARE(true_color_chroma_keyed);

//例程入口
void lv_img_test_start()
{
  lv_obj_t *scr = lv_scr_act();//获取当前活跃的屏幕对象

  //1.创建图片的样式
  lv_style_copy(&img_style,&lv_style_transp);
  img_style.image.color = LV_COLOR_RED;//图片重绘色时的混合颜色或者文本的颜色
  img_style.image.intense = 0;//暂时不使能重绘色功能
  img_style.image.opa = LV_OPA_COVER;//透明度

  //2.创建显示图标字体和文本的图片对象
  lv_obj_t * img1 = lv_img_create(scr,NULL);
  lv_img_set_src(img1,LV_SYMBOL_DUMMY"Icon font: "LV_SYMBOL_AUDIO" audio");//以文本开头,前面必须得加LV_SYMBOL_DUMMY
  lv_img_set_style(img1,LV_IMG_STYLE_MAIN,&img_style);//设置样式
  lv_obj_align(img1,NULL,LV_ALIGN_IN_TOP_MID,0,10);

  //3.创建显示True color格式的图片对象
  lv_obj_t * img2 = lv_img_create(scr,NULL);
  lv_img_set_src(img2,&true_color);
  lv_img_set_style(img2,LV_IMG_STYLE_MAIN,&img_style);//设置样式
  lv_obj_align(img2,img1,LV_ALIGN_OUT_BOTTOM_MID,0,10);

  //4.创建显示True color with alpha格式的图片对象
  lv_obj_t * img3 = lv_img_create(scr,NULL);
  lv_img_set_src(img3,&true_color_with_alpha);
  lv_img_set_style(img3,LV_IMG_STYLE_MAIN,&img_style);//设置样式
  lv_obj_align(img3,img2,LV_ALIGN_OUT_BOTTOM_MID,0,10);

  //5.创建显示True color chroma keyed格式的图片对象
  //同时需要把lv_conf.h中LV_COLOR_TRANSP宏的值改为LV_COLOR_GREEN纯绿色,目的就是为了保持和此图片的背景色一致,
  //不过LV_COLOR_TRANSP的默认值就是纯绿色的
  lv_obj_t * img4 = lv_img_create(scr,NULL);
  lv_img_set_src(img4,&true_color_chroma_keyed);
  lv_img_set_style(img4,LV_IMG_STYLE_MAIN,&img_style);//设置样式
  lv_img_set_auto_size(img4,false);//不使能大小自动适配
  lv_obj_set_size(img4,150,50);//设置lv_img控件的宽度是true_color_chroma_keyed图片宽度的3倍,高度相等,可以看到在水平方向上有图片重复绘制现象
  lv_obj_align(img4,img3,LV_ALIGN_OUT_BOTTOM_MID,0,10);

}


//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		//修改样式中的重绘色强度
		img_style.image.intense += 10;
		if(img_style.image.intense>=250)
			img_style.image.intense = 0;
		lv_obj_report_style_mod(&img_style);//刷新使用了此样式的对象
	}else if(key==KEY1_PRESS)
	{
		//修改样式中的透明度
		img_style.image.opa -= 10;
		if(img_style.image.opa<=10)
			img_style.image.opa = LV_OPA_COVER;
		lv_obj_report_style_mod(&img_style);//刷新使用了此样式的对象
	}
}




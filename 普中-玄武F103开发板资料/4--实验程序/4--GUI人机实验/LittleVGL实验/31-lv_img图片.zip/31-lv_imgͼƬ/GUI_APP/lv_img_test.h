#ifndef __LV_IMG_TEST_H__
#define __LV_IMG_TEST_H__
#include "system.h"



//��������
void lv_img_test_start(void);
void key_handler(void);
#endif



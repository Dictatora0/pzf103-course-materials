#include "lv_line_test.h"
#include "lvgl.h"
#include "key.h"

const lv_point_t line_points[] = { {10, 20}, {70, 50}, {120, 10}, {140, 60}, {180, 10} };//坐标点集合
#define LINE_POINTS_NUM         (sizeof(line_points)/sizeof(line_points[0]))   //坐标点的个数

lv_obj_t * line1;

//例程入口
void lv_line_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建自定义样式
	static lv_style_t line_style;
	lv_style_copy(&line_style, &lv_style_plain);
	line_style.line.color = LV_COLOR_RED;//线条的颜色
	line_style.line.width = 4;//线条的厚度
	line_style.line.rounded = 1;//线条的末端是否为圆角

	//2.创建线条对象
	line1 = lv_line_create(scr, NULL);//创建线条对象
	lv_obj_set_pos(line1,20,20);//设置坐标
	lv_line_set_auto_size(line1,true);//使能大小自适应,当然了,你也可以不调用,因为默认就是被使能了的
	lv_line_set_points(line1, line_points, LINE_POINTS_NUM);//设置坐标点集合,同时也会在此内部计算出线条对象的大小
	lv_line_set_style(line1, LV_LINE_STYLE_MAIN, &line_style);//设置样式
}


//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		lv_line_set_y_invert(line1,!lv_line_get_y_invert(line1));//来回取反
	}
}



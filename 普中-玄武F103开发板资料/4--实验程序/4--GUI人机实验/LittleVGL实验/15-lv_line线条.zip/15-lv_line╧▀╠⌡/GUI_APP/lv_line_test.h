#ifndef __LV_LINE_TEST_H__
#define __LV_LINE_TEST_H__
#include "system.h"





//��������
void lv_line_test_start(void);
void key_handler(void);

#endif



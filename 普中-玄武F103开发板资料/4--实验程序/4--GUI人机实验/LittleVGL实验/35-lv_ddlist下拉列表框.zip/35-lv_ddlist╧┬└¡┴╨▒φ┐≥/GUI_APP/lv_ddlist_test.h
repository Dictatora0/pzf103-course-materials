#ifndef __LV_DDLIST_TEST_H__
#define __LV_DDLIST_TEST_H__
#include "system.h"



//��������
void lv_ddlist_test_start(void);
void key_handler(void);

#endif



#include "lv_list_test.h"
#include "lvgl.h"
#include "key.h"
#include <stdio.h>

lv_style_t bg_style;
lv_obj_t * list1;
lv_obj_t * last_item_btn;

//定义列表项按钮
const char * const LIST_ITEM_BTN[][2] = {
  {LV_SYMBOL_FILE,"This is a long long text!"},//含有长文本内容,将会看到循环滚动效果
  {NULL,"Open"},//不给图标
  {LV_SYMBOL_CLOSE,"Close"},
  {LV_SYMBOL_EDIT,"Edit"},
  {LV_SYMBOL_SAVE,"Save"}
};
#define LIST_ITEM_BTN_NUM   (sizeof(LIST_ITEM_BTN)/sizeof(LIST_ITEM_BTN[0]))  //总共有多少个列表项按钮


//事件回调函数
static void event_handler(lv_obj_t * obj,lv_event_t event)
{
  if(event==LV_EVENT_RELEASED)
  {
    printf("list item btn: %s\r\n",lv_list_get_btn_text(obj));//将按下按钮的文本给打印出来
  }
}



//例程入口
void lv_list_test_start()
{
	lv_obj_t *scr = lv_scr_act();//获取当前活跃的屏幕对象

  //1.创建背景样式
  lv_style_copy(&bg_style,&lv_style_transp);
  bg_style.body.border.width = 2;
  bg_style.body.border.color = LV_COLOR_MAKE(0x36,0x5D,0x85);
  bg_style.body.radius = 6;
  bg_style.body.padding.right = 8;//给右侧的滚动条留点空间

  //2.创建列表对象
  list1 = lv_list_create(scr,NULL);
  lv_obj_set_size(list1,150,150);//设置大小
  lv_obj_align(list1,NULL,LV_ALIGN_CENTER,0,0);//与屏幕居中对齐
  lv_list_set_single_mode(list1,true);//使能列表的单选模式
  lv_list_set_sb_mode(list1,LV_SB_MODE_AUTO);//设置滚动条模式
  lv_list_set_style(list1,LV_LIST_STYLE_BG,&bg_style);//设置背景样式
  lv_list_set_style(list1,LV_LIST_STYLE_SCRL,&lv_style_transp);//设置页面中容器载体的样式
  //2.1 添加列表项按钮
  uint8_t i;
  lv_obj_t * list_item_btn;
  for(i=0;i<LIST_ITEM_BTN_NUM;i++)
  {
    list_item_btn = lv_list_add_btn(list1,LIST_ITEM_BTN[i][0],LIST_ITEM_BTN[i][1]);//添加列表项按钮
    lv_obj_set_event_cb(list_item_btn,event_handler);//给列表项按钮设置事件回调函数
  }
  last_item_btn = list_item_btn;//保存最后一个列表项按钮对象
}


//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		lv_list_up(list1);//让列表向上移动一步
	}else if(key==KEY1_PRESS)
	{
		lv_list_down(list1);//让列表向下移动一步
	}else if(key==KEY_UP_PRESS)
	{
		lv_list_focus(last_item_btn,LV_ANIM_ON);//让最后一个列表项按钮直接处于可见状态
	}
}






#ifndef __LV_LIST_TEST_H__
#define __LV_LIST_TEST_H__
#include "system.h"



//��������
void lv_list_test_start(void);
void key_handler(void);

#endif



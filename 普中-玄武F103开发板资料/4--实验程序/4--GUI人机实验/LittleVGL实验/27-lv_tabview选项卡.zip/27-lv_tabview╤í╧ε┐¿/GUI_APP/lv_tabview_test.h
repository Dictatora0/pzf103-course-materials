#ifndef __LV_TABVIEW_TEST_H__
#define __LV_TABVIEW_TEST_H__
#include "system.h"



//��������
void lv_tabview_test_start(void);
void key_handler(void);
#endif



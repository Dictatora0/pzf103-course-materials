#include "lv_imgbtn_test.h"
#include "lvgl.h"
#include <stdio.h>

//图片申明
LV_IMG_DECLARE(btn_img1);
LV_IMG_DECLARE(btn_img2);

lv_style_t pr_style;

//事件回调函数
void event_handler(lv_obj_t * obj,lv_event_t event)
{
  if(event==LV_EVENT_VALUE_CHANGED)
  {
    printf("LV_EVENT_VALUE_CHANGED\r\n");
  }
}

//例程入口
void lv_imgbtn_test_start()
{
  lv_obj_t *scr = lv_scr_act();//获取当前活跃的屏幕对象


  //1.创建按下时的样式
  lv_style_copy(&pr_style,&lv_style_plain);
  pr_style.image.color = LV_COLOR_BLACK;//图片重绘色时的混合色为黑色,这样看上去有按下的效果
  pr_style.image.intense = LV_OPA_50;//混合强度
  pr_style.text.color = LV_COLOR_MAKE(0xAA,0xAA,0xAA);//按下时的文本色

  //2.创建图片按钮对象
  lv_obj_t * imgbtn1 = lv_imgbtn_create(scr,NULL);
  lv_imgbtn_set_src(imgbtn1,LV_BTN_STATE_REL,&btn_img1);//设置正常态松手时的图片
  lv_imgbtn_set_src(imgbtn1,LV_BTN_STATE_PR,&btn_img1);//设置正常态按下时的图片
  lv_imgbtn_set_src(imgbtn1,LV_BTN_STATE_TGL_REL,&btn_img2);//设置toggle切换态松手时的图片
  lv_imgbtn_set_src(imgbtn1,LV_BTN_STATE_TGL_PR,&btn_img2);//设置toggle切换态按下时的图片
  lv_imgbtn_set_style(imgbtn1,LV_BTN_STATE_PR,&pr_style);//设置正常态按下时的样式
  lv_imgbtn_set_style(imgbtn1,LV_BTN_STATE_TGL_PR,&pr_style);//设置toggle切换态按下时的样式
  lv_imgbtn_set_toggle(imgbtn1,true);//使能toggle功能
  lv_obj_align(imgbtn1,NULL,LV_ALIGN_CENTER,0,0);//与屏幕居中对齐
  lv_obj_set_event_cb(imgbtn1,event_handler);//设置事件回调函数
  lv_obj_t * label1 = lv_label_create(imgbtn1,NULL);//给图片按钮添加标题
  lv_label_set_text(label1, "img btn");
}














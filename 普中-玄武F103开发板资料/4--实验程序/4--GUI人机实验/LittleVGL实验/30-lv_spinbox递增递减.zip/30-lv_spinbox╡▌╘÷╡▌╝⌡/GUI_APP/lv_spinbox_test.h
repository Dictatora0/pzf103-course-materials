#ifndef __LV_SPINBOX_TEST_H__
#define __LV_SPINBOX_TEST_H__
#include "system.h"



//��������
void lv_spinbox_test_start(void);
void key_handler(void);
#endif



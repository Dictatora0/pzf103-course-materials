#include "lv_spinbox_test.h"
#include "lvgl.h"
#include "key.h"
#include <stdio.h>


lv_obj_t * spinbox1;

//事件回调函数
void event_handler(lv_obj_t * obj,lv_event_t event)
{
  if(event==LV_EVENT_VALUE_CHANGED)
  {
    printf("spinbox value:%d\r\n",lv_spinbox_get_value(spinbox1));
  }
}

//例程入口
void lv_spinbox_test_start()
{
  lv_obj_t *scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建spinbox对象
  spinbox1 = lv_spinbox_create(scr,NULL);
  lv_obj_set_size(spinbox1,80,30);//设置大小
  lv_obj_align(spinbox1,NULL,LV_ALIGN_CENTER,0,0);//与屏幕居中对齐
  lv_spinbox_set_step(spinbox1,10);//设置step步值为10
  lv_spinbox_set_range(spinbox1,-1000,1000);//设置数值范围[-1000,1000]
  lv_spinbox_set_padding_left(spinbox1,3);//设置空格间隙
  lv_spinbox_set_digit_format(spinbox1,4,3);//设置显示格式,数值总共4位,小数点在第3位
  lv_spinbox_set_value(spinbox1,0);//设置起始值为0
	lv_obj_set_event_cb(spinbox1,event_handler);//设置事件回调函数
}


//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		lv_spinbox_increment(spinbox1);//进行递增操作
	}else if(key==KEY1_PRESS)
	{
		lv_spinbox_decrement(spinbox1);//进行递减操作
	}
}




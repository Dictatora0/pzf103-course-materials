#include "lv_mbox_test.h"
#include "lvgl.h"


lv_style_t bg_style;
lv_style_t btnm_bg_style;
lv_style_t btn_rel_style;
lv_style_t btn_pr_style;
lv_obj_t * open_btn;
lv_obj_t * mbox1;
const char * const btns_map[] ={"#5FB878 Apply#","\n","#ff0000 Close#",""};

lv_obj_t * mbox_create(lv_obj_t * parent);//函数申明



//事件回调函数
void event_handler(lv_obj_t * obj,lv_event_t event)
{
	uint16_t btn_id;
  if(obj==open_btn)//是打开按钮
  {
    if(event==LV_EVENT_RELEASED)
    {
			//重新在创建一个消息对话框
      mbox1 = mbox_create(lv_scr_act());
    }
  }else if(obj==mbox1)//是消息对话框
  {
		if(event==LV_EVENT_VALUE_CHANGED)
		{
			//获取按钮id
			btn_id = lv_mbox_get_active_btn(obj);//也可以使用btn_id = *((uint16_t*)lv_event_get_data());的方式
			
			if(btn_id==0)//Apply按钮
			{
				//马上关闭消息对话框
				lv_mbox_start_auto_close(obj,0);//也可以使用lv_obj_del(obj);只不过lv_obj_del是立即关闭,而且无关闭动画效果
			}else if(btn_id==1)//Close按钮
			{
				//定时关闭消息对话框
				lv_mbox_start_auto_close(obj,2000);//定时2秒
			}
		}
  }
}


//我们自己定义一个接口,来设置其内部的消息内容标签是否使能文本重绘色功能
//因为littleVGL没有提供这样的接口,所以我们得自己来实现
void mbox_set_msg_recolor(lv_obj_t * mbox,bool en)
{
	lv_mbox_ext_t * ext = lv_obj_get_ext_attr(mbox);//获取控件的扩展字段
	lv_label_set_recolor(ext->text,en);//ext->text就是消息对话框内部的标签对象
}

//创建自己封装之后的消息对话框
//parent:父对象
//返回值: 返回创建出来的消息对话框对象
lv_obj_t * mbox_create(lv_obj_t * parent)
{
  #define MBOX_WIDTH        220  //消息对话框的宽度
  #define MBOX_BTN_HEIGHT   30   //其内部每个按钮的高度
  #define MBOX_BTN_NUM      2    //其内部含有多少个按钮,我们这里只有Apply和Close俩个按钮

  lv_obj_t * mbox = lv_mbox_create(parent,NULL);//创建消息对话框
  mbox_set_msg_recolor(mbox,true);//使能消息内容的文本重绘色,这样就可以对标题进行加色区分了
  lv_mbox_set_text(mbox,"#007AFF Title#\nThis is a message");//设置消息内容,附带设置标题,同时对标题重绘色
  lv_mbox_add_btns(mbox,(const char**)btns_map);//设置按钮映射表
  lv_mbox_set_recolor(mbox,true);//使能其内部按钮的文本重绘色功能
  lv_obj_set_width(mbox,MBOX_WIDTH);//设置固定的宽度,高度会自适应的
  lv_obj_align(mbox,NULL,LV_ALIGN_CENTER,0,0);//设置与父对象居中对齐
  lv_obj_set_event_cb(mbox,event_handler);//设置事件回调函数
  lv_mbox_set_style(mbox,LV_MBOX_STYLE_BG,&bg_style);//设置消息对话框的背景样式
  lv_mbox_set_style(mbox,LV_MBOX_STYLE_BTN_BG,&btnm_bg_style);//设置其内部矩阵按钮的背景样式
  lv_mbox_set_style(mbox,LV_MBOX_STYLE_BTN_REL,&btn_rel_style);//设置按钮释放状态的样式
  lv_mbox_set_style(mbox,LV_MBOX_STYLE_BTN_PR,&btn_pr_style);//设置按钮按下状态的样式
  
	//最好在消息对话框全部初始化完成之后,再来设置其内部矩阵按钮的各种特性,否则有可能得不到预期的效果
  lv_obj_t * btnm_of_mbox = lv_mbox_get_btnm(mbox);//获取其内部的矩阵按钮对象
  lv_obj_set_size(btnm_of_mbox,MBOX_WIDTH,MBOX_BTN_HEIGHT*MBOX_BTN_NUM);//设置矩阵按钮的大小

  return mbox;
}


//例程入口
void lv_mbox_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

  //1.创建4种样式
  //1.1 创建消息对话框的背景样式
  lv_style_copy(&bg_style,&lv_style_plain_color);
  bg_style.body.main_color = LV_COLOR_MAKE(250,250,250);//背景颜色
  bg_style.body.grad_color = bg_style.body.main_color;
  bg_style.body.radius = 10;//圆角半径
  bg_style.body.border.width = 1;//边框宽度
  bg_style.body.border.color = LV_COLOR_MAKE(150,150,150);//边框颜色
  bg_style.body.shadow.color = bg_style.body.border.color;//阴影颜色
  bg_style.body.shadow.width = 6;//阴影的宽度
  bg_style.body.padding.top = 10;//设置其内部的消息内容与消息对话框上边框之间的距离
  bg_style.body.padding.bottom = 0;//设置其内部的矩阵按钮与消息对话框底边框之间的距离
  bg_style.body.padding.inner = 10;//设置消息内容与矩阵按钮之间的距离
  bg_style.text.color = LV_COLOR_BLACK;//消息内容的文本颜色
  //1.2 创建矩阵按钮的背景样式
  lv_style_copy(&btnm_bg_style,&lv_style_transp_tight);
  btnm_bg_style.body.padding.top = 0; //设置各种内边距全部为0,其实lv_style_transp_tight样式默认就是各种内边距全为0的
  btnm_bg_style.body.padding.left = 0;
  btnm_bg_style.body.padding.right = 0;
  btnm_bg_style.body.padding.bottom = 0;
  btnm_bg_style.body.padding.inner = 0;
  //1.3 创建按钮释放状态的样式
  lv_style_copy(&btn_rel_style,&lv_style_transp);
  btn_rel_style.body.border.part = LV_BORDER_TOP;//只绘制上边框
  btn_rel_style.body.border.width = 1;//边框的宽度
  btn_rel_style.body.border.color = bg_style.body.border.color;//边框的颜色
  //1.4 创建按钮按下状态的样式
  lv_style_copy(&btn_pr_style,&btn_rel_style);
  btn_pr_style.body.opa = LV_OPA_COVER;//完全不透明
  btn_pr_style.body.border.part = LV_BORDER_FULL;//绘制四边
  btn_pr_style.body.main_color = LV_COLOR_MAKE(200,200,200);//背景颜色
  btn_pr_style.body.grad_color = btn_pr_style.body.main_color;

  //2.创建一个按钮来打开消息对话框
  open_btn = lv_btn_create(scr,NULL);
  lv_obj_set_size(open_btn,150,60);
  lv_obj_set_event_cb(open_btn,event_handler);//设置按钮的事件回调函数
  lv_obj_t * label1 = lv_label_create(open_btn,NULL);
  lv_label_set_text(label1,"Open mbox");
  lv_obj_align(open_btn,NULL,LV_ALIGN_CENTER,0,0);//与屏幕居中对齐

  //3.创建封装之后的消息对话框
  mbox1 = mbox_create(scr);
}



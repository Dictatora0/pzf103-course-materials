#include "lv_btnm_test.h"
#include "lvgl.h"
#include "key.h"
#include <stdio.h>

lv_obj_t * btnm1,* btnm2;
lv_obj_t * label1;
lv_style_t bg_style;

//第二个const表示把此映射表放在flash存储区,而不是sram,可以减少内存的开销
static const char * const btnm1_map[] = {//btnm1的按钮映射表
	"    "LV_SYMBOL_AUDIO"\n#ff0000 AUDIO#", "   "LV_SYMBOL_VIDEO"\n#ff0000 VIDEO#",//第一行放2个按钮
	"\n",//换行
	"    "LV_SYMBOL_HOME"\n#ff0000 HOME#", "   "LV_SYMBOL_SAVE"\n#ff0000 SAVE#",//第二行放2个按钮
	"" //空字符串作为结束符
};


static const char * const btnm2_map[] = {//btnm2的按钮映射表
	"Btn1","Btn2","Btn3",
	"" //空字符串作为结束符
};


//事件回调函数
static void event_handler(lv_obj_t * obj,lv_event_t event)
{
	static uint32_t cnt = 0;//记录进入LV_EVENT_VALUE_CHANGED事件的次数
	char buff[100];
	const char * btn_title;
	uint16_t btn_id;

	if(event==LV_EVENT_VALUE_CHANGED)
	{
		//1.计数器增1
		cnt++;
		//2.获取当前被点击了的按钮标题
		btn_title = lv_btnm_get_active_btn_text(obj);
		//3.获取当前被点击了的按钮id
		btn_id = *((uint16_t*)lv_event_get_data());//方式1
		//btn_id = lv_btnm_get_active_btn(obj);//方式2
		//4.把事件信息显示在标签上
		sprintf(buff,"obj:%s,btn_id:%d,btn_title:%s,cnt:%d,",obj==btnm1?"btnm1":"btnm2",btn_id,btn_title,cnt);
		lv_label_set_text(label1,buff);
	}
}


//例程入口
void lv_btnm_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象


	//1.创建一个自定义样式,用于修饰lv_btnm的背景
	lv_style_copy(&bg_style,&lv_style_pretty);
	bg_style.body.padding.top = 5;//上内边距
	bg_style.body.padding.bottom = 5;//底内边距
	bg_style.body.padding.left = 15;//左内边距
	bg_style.body.padding.right = 15;//右内边距
	bg_style.body.padding.inner = 5;//按钮与按钮之间的距离

	//2.创建一个类似于主菜单效果的btnm1
	btnm1 = lv_btnm_create(scr,NULL);
	lv_obj_set_size(btnm1,160,160);//设置大小
	lv_obj_align(btnm1,NULL,LV_ALIGN_IN_TOP_MID,0,10);//设置与屏幕的对齐方式
	lv_btnm_set_map(btnm1,(const char**)btnm1_map);//设置按钮映射表
	lv_btnm_set_recolor(btnm1,true);//使能颜色重绘
	lv_btnm_set_style(btnm1,LV_BTNM_STYLE_BG,&bg_style);//设置背景样式
	lv_obj_set_event_cb(btnm1,event_handler);//设置事件回调函数

	//3.创建btnm2,用来演示One Toggle特性
	btnm2 = lv_btnm_create(scr,NULL);
	lv_obj_set_size(btnm2,220,50);//设置大小
	lv_obj_align(btnm2,btnm1,LV_ALIGN_OUT_BOTTOM_MID,0,10);//设置与btnm1的对齐方式
	lv_btnm_set_map(btnm2,(const char**)btnm2_map);//设置按钮映射表
	lv_btnm_set_btn_width(btnm2,1,2);//设置Btn2按钮的宽度是其他按钮的2倍
	lv_btnm_set_btn_ctrl_all(btnm2,LV_BTNM_CTRL_TGL_ENABLE);//所有按钮都设置为Toggle按钮,至少得有2个以上的Toggle按钮才能看到One Toggle效果
	lv_btnm_set_one_toggle(btnm2,true);//使能One Toggle特性
	lv_btnm_set_btn_ctrl(btnm2,2,LV_BTNM_CTRL_TGL_STATE);//让Btn3默认就处于Toggle状态
	lv_obj_set_event_cb(btnm2,event_handler);//设置事件回调函数

	//4.创建一个label标签用来显示信息
	label1 = lv_label_create(scr,NULL);
	lv_label_set_long_mode(label1,LV_LABEL_LONG_BREAK);//设置长文本模式
	lv_obj_set_width(label1,220);//设置宽度
	lv_obj_align(label1,btnm2,LV_ALIGN_OUT_BOTTOM_MID,0,10);//设置与btnm2的对齐方式
	lv_label_set_body_draw(label1,true);//使能背景绘制
	lv_label_set_recolor(label1,true);//使能文本重绘色
	lv_label_set_style(label1,LV_LABEL_STYLE_MAIN,&lv_style_plain_color);//设置背景
	lv_label_set_text(label1,"Event info");
}

//来回切换btnm1中某个按钮的控制属性
static void btnm1_toggle_btn_ctrl(uint16_t btn_id,lv_btnm_ctrl_t ctrl)
{
	if(lv_btnm_get_btn_ctrl(btnm1,btn_id,ctrl))//判断此按钮是否已经设置了ctrl控制属性
		lv_btnm_clear_btn_ctrl(btnm1,btn_id,ctrl);//清除掉
	else
		lv_btnm_set_btn_ctrl(btnm1,btn_id,ctrl);//重新设置
}

//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		btnm1_toggle_btn_ctrl(0,LV_BTNM_CTRL_HIDDEN);//来回切换AUDIO按钮的隐藏控制属性
	}else if(key==KEY1_PRESS)
	{
		btnm1_toggle_btn_ctrl(1,LV_BTNM_CTRL_INACTIVE);//来回切换VIDEO按钮的禁用控制属性
	}else if(key==KEY2_PRESS)
	{
		btnm1_toggle_btn_ctrl(2,LV_BTNM_CTRL_NO_REPEAT);//来回切换HOME按钮的禁用重复长按控制属性
	}else if(key==KEY_UP_PRESS)
	{
		btnm1_toggle_btn_ctrl(3,LV_BTNM_CTRL_CLICK_TRIG);//来回切换SAVE按钮的松手触发控制属性,如果不设置的话,默认是按下时触发
	}
}


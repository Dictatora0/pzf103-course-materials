#include "lv_btn_test.h"
#include "lvgl.h"

lv_style_t my_style_btn_release;//按钮释放状态下的样式
lv_style_t my_style_btn_press;//按钮按下时的样式
lv_obj_t * btn1,* btn2,* btn3;
lv_obj_t * btn2_label,* btn3_label;


//事件回调函数
static void btn_event_cb(lv_obj_t * obj,lv_event_t event)
{
	if(event==LV_EVENT_RELEASED)
	{
		if(obj==btn2)
		{
			lv_btn_state_t state = lv_btn_get_state(btn2);//获取切换按钮的当前状态
			lv_label_set_text(btn2_label,state==LV_BTN_STATE_TGL_REL?"Toggle":"Normal");//切换态或者正常态
		}else if(obj==btn3)
			lv_label_ins_text(btn3_label,LV_LABEL_POS_LAST," long ");//当点击时,在最后面增加文本的内容
	}
}

//例程入口函数
void lv_btn_test_start()
{
	lv_obj_t* src = lv_scr_act();//获取当前活跃的屏幕对象

	//1.先创建2种状态下按钮样式
	//1.1 释放状态下的样式
	lv_style_copy(&my_style_btn_release,&lv_style_plain_color);
	my_style_btn_release.body.main_color = LV_COLOR_MAKE(0x1E,0x9F,0xFF);//设置纯色的背景
	my_style_btn_release.body.grad_color = my_style_btn_release.body.main_color;
	my_style_btn_release.body.opa = LV_OPA_COVER;//设置背景色完全不透明
	my_style_btn_release.body.radius = LV_RADIUS_CIRCLE;//绘制圆角按钮
	my_style_btn_release.body.shadow.color = LV_COLOR_MAKE(0x1E,0x9F,0xFF);
	my_style_btn_release.body.shadow.type = LV_SHADOW_FULL;//设置四边都有阴影
	my_style_btn_release.body.shadow.width = 3;//设置阴影的宽度
	my_style_btn_release.text.color = LV_COLOR_WHITE;
	my_style_btn_release.body.padding.left = 10;//设置左内边距
	my_style_btn_release.body.padding.right = 10;//设置右内边距

	//1.2 按下状态下的样式
	lv_style_copy(&my_style_btn_press,&lv_style_plain_color);
	my_style_btn_press.body.opa = LV_OPA_0;//设置背景色透明
	my_style_btn_press.body.radius = LV_RADIUS_CIRCLE;//绘制圆角按钮
	my_style_btn_press.body.border.color = LV_COLOR_MAKE(0xC9,0xC9,0xC9);//设置边框的颜色
	my_style_btn_press.body.border.part = LV_BORDER_FULL;//四条边框都绘制
	my_style_btn_press.body.border.width = 2;//设置边框的宽度
	my_style_btn_press.body.border.opa = LV_OPA_COVER;//设置边框完全不透明
	my_style_btn_press.text.color = LV_COLOR_BLACK;
	my_style_btn_press.body.padding.left = 10;//设置左内边距
	my_style_btn_press.body.padding.right = 10;//设置右内边距

	//2.创建一个默认的按钮,同时使能其波纹点击效果,任何一个对象创建之后,其默认的宽度为LV_OBJ_DEF_WIDTH,默认的高度为LV_OBJ_DEF_HEIGHT
	//而LV_OBJ_DEF_WIDTH和LV_OBJ_DEF_HEIGHT宏的值是受lv_conf.h文件中LV_DPI配置项的影响,具体关系如下:
	//#define LV_OBJ_DEF_WIDTH  (LV_DPI)
	//#define LV_OBJ_DEF_HEIGHT (2 * LV_DPI / 3)
	btn1 = lv_btn_create(src, NULL);
	lv_obj_set_pos(btn1,20,20);//设置坐标
	lv_btn_set_ink_in_time(btn1, 3000);//入场动画时长
	lv_btn_set_ink_wait_time(btn1, 1000);//维持等待时长
	lv_btn_set_ink_out_time(btn1, 600);//出场动画时长,这个出场动画是淡出效果的,请睁大眼睛观看,否则不容易看出效果

	//3.创建一个Toggle切换按钮
	btn2 = lv_btn_create(src, NULL);
	lv_obj_set_size(btn2,90,30);//设置大小
	lv_obj_align(btn2, btn1, LV_ALIGN_OUT_RIGHT_TOP, 20, 0);//设置对齐方式
	lv_btn_set_toggle(btn2,true);//设置为Toggle按钮
	lv_btn_set_state(btn2,LV_BTN_STATE_TGL_REL);//设置按钮的起始状态为切换态下的释放状态

	lv_btn_set_style(btn2,LV_BTN_STYLE_TGL_REL,&my_style_btn_release);//设置按钮切换态下的释放状态样式
	lv_btn_set_style(btn2,LV_BTN_STYLE_TGL_PR,&my_style_btn_release);//设置按钮切换态下的按下状态样式,为了看起来更美观和谐,使其和LV_BTN_STYLE_TGL_REL的样式值保持一致
	lv_btn_set_style(btn2,LV_BTN_STYLE_REL,&my_style_btn_press);//设置按钮正常态下释放状态样式
	lv_btn_set_style(btn2,LV_BTN_STYLE_PR,&my_style_btn_press);//设置按钮正常态下按下状态样式,为了看起来更美观和谐,使其和LV_BTN_STYLE_REL的样式值保持一致

	btn2_label = lv_label_create(btn2,NULL);//给btn2添加label子对象
	lv_label_set_text(btn2_label,"Toggle");

	lv_btn_set_layout(btn2,LV_LAYOUT_CENTER);//设置按钮2的布局方式,使label处于正中间,当然了如果不设置的话,默认也是正中间的

	lv_obj_set_event_cb(btn2,btn_event_cb);//设置btn2的事件回调

	//3.创建一个宽度自适应的正常按钮
	btn3 = lv_btn_create(src, NULL);
	lv_obj_align(btn3,btn1,LV_ALIGN_OUT_BOTTOM_LEFT,0,20);//设置对齐
	lv_obj_set_height(btn3,30);//只设置高度固定
	lv_btn_set_fit4(btn3,LV_FIT_NONE,LV_FIT_TIGHT,LV_FIT_NONE,LV_FIT_NONE);//设置宽度只在右边自适应

	lv_btn_set_style(btn3,LV_BTN_STYLE_REL,&my_style_btn_release);//设置按钮正常态下释放状态样式
	lv_btn_set_style(btn3,LV_BTN_STYLE_PR,&my_style_btn_press);//设置按钮正常态下按下状态样式

	btn3_label = lv_label_create(btn3,NULL);//给btn3添加label子对象
	lv_label_set_text(btn3_label,"This is long text");

	lv_obj_set_event_cb(btn3,btn_event_cb);//设置btn3的事件回调
}











#include "lv_canvas_test.h"
#include "lvgl.h"

lv_style_t style;
const lv_point_t points[] = {{50,90},{70,50},{90,90}};//构成线条的点集合

//画布1,用来演示一些绘图API接口
#define CANVAS1_WIDTH   80 //画布1的宽度
#define CANVAS1_HEIGHT  60 //画布1的高度

lv_color_t canvas1_buf[LV_CANVAS_BUF_SIZE_TRUE_COLOR(CANVAS1_WIDTH,CANVAS1_HEIGHT)];

//画布2,用来演示调色板格式
#define CANVAS2_WIDTH   40 //画布2的宽度
#define CANVAS2_HEIGHT  40 //画布2的高度

lv_color_t canvas2_buf[LV_CANVAS_BUF_SIZE_INDEXED_1BIT(CANVAS2_WIDTH,CANVAS2_HEIGHT)];

//例程入口
void lv_canvas_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象
	
	//1.创建样式
	lv_style_copy(&style,&lv_style_plain);
	style.body.main_color = LV_COLOR_RED;
	style.body.grad_color = LV_COLOR_RED;
	style.line.width = 2;
	style.line.color = LV_COLOR_GREEN;
	style.text.color = LV_COLOR_BLUE;

	//2.创建画布1,用来演示一些绘图API接口
	lv_obj_t * canvas1 = lv_canvas_create(scr,NULL);
	lv_canvas_set_buffer(canvas1,canvas1_buf,CANVAS1_WIDTH,CANVAS1_HEIGHT,LV_IMG_CF_TRUE_COLOR);//设置缓冲区,真彩色格式
	lv_obj_align(canvas1,NULL,LV_ALIGN_IN_TOP_MID,0,20);//设置与屏幕的对齐方式
	lv_canvas_fill_bg(canvas1,LV_COLOR_GRAY);//将背景清成灰色
	lv_canvas_draw_rect(canvas1,10,10,60,20,&style);//绘制一个红色的填充矩形
	lv_canvas_draw_text(canvas1,0,35,CANVAS1_WIDTH,&style,"Hello",LV_LABEL_ALIGN_CENTER);//绘制文本内容
	lv_canvas_draw_arc(canvas1,30,60,20,270,90,&style);//绘制弧形
	lv_canvas_draw_line(canvas1,points,sizeof(points)/sizeof(lv_point_t),&style);//绘制线条

	//3.创建画布2,用来演示调色板格式
	lv_obj_t * canvas2 = lv_canvas_create(scr,NULL);
	lv_canvas_set_buffer(canvas2,canvas2_buf,CANVAS2_WIDTH,CANVAS2_HEIGHT,LV_IMG_CF_INDEXED_1BIT);//设置缓冲区,真彩色格式
	lv_obj_align(canvas2,canvas1,LV_ALIGN_OUT_BOTTOM_MID,0,20);//设置与画布1的对齐方式
	//构建调色板,对于LV_IMG_CF_INDEXED_1BIT颜色格式而言,总共有2种颜色
	lv_canvas_set_palette(canvas2,0,LV_COLOR_GREEN);//第一种为绿色
  lv_canvas_set_palette(canvas2,1,LV_COLOR_RED);//第二种为红色,也可以换成LV_COLOR_TRANSP透明色看看效果哦
	//定义2个颜色
	lv_color_t color0;
  lv_color_t color1;
  color0.full = 0;//指向调色板中的第一种颜色
  color1.full = 1;//指向调色板中的第二种颜色
	
	lv_canvas_fill_bg(canvas2,color0);//把背景填充成绿色
	//在画布2的正中间绘制一个20*20大小的矩形
	uint16_t x,y;
	for(y=10;y<30;y++) 
	{
		for(x=10;x<30;x++) 
		{
			lv_canvas_set_px(canvas2,x,y,color1);
		}
  }
}


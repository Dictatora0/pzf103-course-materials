#include "lv_chart_test.h"
#include "lvgl.h"
#include "key.h"

lv_style_t scr_style;

#define POINT_COUNT   10  //每条数据线所具有的数据点个数
lv_style_t main_style;
const lv_coord_t series1_y[POINT_COUNT] = {30,60,40,60,20,60,50,80,60,80};
lv_obj_t * chart1;
lv_chart_series_t * series1;
lv_chart_series_t * series2;

//例程入口
void lv_chart_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象
	lv_style_copy(&scr_style,&lv_style_plain_color);
	scr_style.body.main_color = LV_COLOR_CYAN;
	scr_style.body.grad_color = scr_style.body.main_color;
	lv_obj_set_style(scr,&scr_style);//给屏幕设置一个纯色的背景,让我们的图表显示更明显,同时可以解决色点现象
	
  //1.创建样式
  lv_style_copy(&main_style,&lv_style_pretty);
  main_style.body.main_color = LV_COLOR_WHITE;//主背景为纯白色
  main_style.body.grad_color = main_style.body.main_color;
  main_style.body.border.color = LV_COLOR_BLACK;//边框的颜色
  main_style.body.border.width = 3;//边框的宽度
  main_style.body.border.opa = LV_OPA_COVER;
  main_style.body.radius = 0;
  main_style.line.color = LV_COLOR_GRAY;//分割线和刻度线的颜色
  main_style.text.color = LV_COLOR_BLUE;//主刻度标题的颜色
  //2.创建图表对象
  //2.1 创建图表对象
  chart1 = lv_chart_create(scr,NULL);
  lv_obj_set_size(chart1,180,200);//设置图表的大小
  lv_obj_align(chart1,NULL,LV_ALIGN_CENTER,20,0);//设置对齐方式
  lv_chart_set_type(chart1,LV_CHART_TYPE_POINT|LV_CHART_TYPE_LINE);//设置为散点和折线的组合
  lv_chart_set_series_opa(chart1,LV_OPA_80);//设置数据线的透明度,不设置的话,则LV_OPA_COVER是默认值
  lv_chart_set_series_width(chart1,4);//设置数据线的宽度
  lv_chart_set_series_darking(chart1,LV_OPA_80);//设置数据线的黑阴影效果
  lv_chart_set_style(chart1,LV_CHART_STYLE_MAIN,&main_style);//设置样式
  lv_chart_set_point_count(chart1,POINT_COUNT);//设置每条数据线所具有的数据点个数,如果不设置的话,则默认值是10
  lv_chart_set_div_line_count(chart1,4,4);//设置水平和垂直分割线
  lv_chart_set_range(chart1,0,100);//设置y轴的数值范围,[0,100]也是默认值
  lv_chart_set_y_tick_length(chart1,10,3);//设置y轴的主刻度线长度和次刻度线长度
  lv_chart_set_y_tick_texts(chart1,"100\n80\n60\n40\n20\n0",2,LV_CHART_AXIS_DRAW_LAST_TICK);
  lv_chart_set_x_tick_length(chart1,10,3);//设置x轴的主刻度线长度和次刻度线长度
  lv_chart_set_x_tick_texts(chart1,"0\n2\n4\n6\n8\n10",2,LV_CHART_AXIS_DRAW_LAST_TICK);//设置x轴的刻度数和主刻度标题
  lv_chart_set_margin(chart1,40);//设置刻度区域的高度
  //2.2 往图表中添加第1条数据线
  series1 = lv_chart_add_series(chart1,LV_COLOR_RED);//指定为红色
  lv_chart_set_points(chart1,series1,(lv_coord_t*)series1_y);//初始化数据点的值
  series1->points[1] = 70;//也可以采用直接修改的方式
  lv_chart_refresh(chart1);//如果是采用直接修改的方式,请最好调用一下刷新操作
  //2.3 往图表中添加第2条数据线
  series2 = lv_chart_add_series(chart1,LV_COLOR_BLUE);//指定为蓝色
  lv_chart_init_points(chart1,series2,90);//给所有数据点设置统一的值

}


//按键处理
void key_handler()
{
	static u8 type_index = 0;//图表的模式
	static lv_chart_update_mode_t update_mode = LV_CHART_UPDATE_MODE_SHIFT;//数据点更新模式
	
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		//为了使数据线的图表类型变化看得更明显,我们把series2数据线给隐藏了,防止干扰视线
		lv_chart_clear_serie(chart1,series2);
		//来回切换图表类型
		lv_chart_set_type(chart1,(lv_chart_type_t)(0x01<<type_index));
		type_index++;
		if(type_index==6)
			type_index = 0;
	}else if(key==KEY1_PRESS)
	{
		//往series1数据线上添加新的数据点
		//可以切换到不同的数据点更新模式来观看不同的效果
		lv_chart_set_next(chart1,series1,40);
	}else if(key==KEY2_PRESS)
	{
		//来回切换数据点的更新模式
		//如果不设置的话,则默认是LV_CHART_UPDATE_MODE_SHIFT左平移模式
		update_mode = !update_mode;
		lv_chart_set_update_mode(chart1,update_mode);
		//为了使效果看起来更明显,我们将series1数据线的值初始化到原始状态
		lv_chart_set_points(chart1,series1,(lv_coord_t*)series1_y);
	}
}

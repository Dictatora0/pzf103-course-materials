#ifndef __LV_CHART_TEST_H__
#define __LV_CHART_TEST_H__
#include "system.h"



//��������
void lv_chart_test_start(void);
void  key_handler(void);
#endif



#include "lv_preload_test.h"
#include "lvgl.h"

lv_style_t main_style;
lv_obj_t * preload1;

//例程入口
void lv_preload_test_start()
{
  lv_obj_t *scr = lv_scr_act();//获取当前活跃的屏幕对象

  //1.创建样式
  lv_style_copy(&main_style,&lv_style_plain);
  //1.1 修饰小圆弧
  main_style.line.width = 10;//小圆弧的宽度
  main_style.line.color = LV_COLOR_GREEN;//小圆弧的颜色
  //1.2 修饰背景圆环
  main_style.body.border.color = LV_COLOR_GRAY;//背景圆环的颜色
  main_style.body.border.width = 10;//背景圆环的宽度
  main_style.body.padding.left = 0;//让小圆弧和背景圆环重合在一起

  //2.创建preload1预加载对象
  preload1 = lv_preload_create(scr,NULL);
  lv_obj_set_size(preload1,120,120);//设置大小
  lv_obj_align(preload1,NULL,LV_ALIGN_CENTER,0,0);//与屏幕居中对齐
  lv_preload_set_style(preload1,LV_PRELOAD_STYLE_MAIN,&main_style);//设置样式
  lv_preload_set_arc_length(preload1,45);//设置小圆弧对应的角度
  lv_preload_set_dir(preload1,LV_PRELOAD_DIR_BACKWARD);//设置为逆时针旋转
  lv_preload_set_type(preload1,LV_PRELOAD_TYPE_FILLSPIN_ARC);//设置旋转动画的方式
  lv_preload_set_spin_time(preload1,2000);//设置旋转的速度,转一圈所需要的时间	
	
}



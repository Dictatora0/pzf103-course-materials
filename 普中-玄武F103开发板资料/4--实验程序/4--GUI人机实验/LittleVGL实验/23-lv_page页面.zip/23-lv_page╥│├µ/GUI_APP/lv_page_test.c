#include "lv_page_test.h"
#include "lvgl.h"
#include "key.h"
#include <stdio.h>


lv_style_t sb_style;
lv_style_t edge_flash_style;
lv_obj_t * page1;
lv_obj_t * btn1;
lv_sb_mode_t sb_mode = LV_SB_MODE_AUTO;

//事件回调函数
void event_handler(lv_obj_t * obj,lv_event_t event)
{
	if(event==LV_EVENT_RELEASED)
	{
		lv_page_clean(page1);//清空内部的所有子对象
	}
}

//例程入口
void lv_page_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建2个样式
	//1.1 创建滚动条的样式
	lv_style_copy(&sb_style,&lv_style_plain);
	sb_style.body.main_color = LV_COLOR_BLACK;
	sb_style.body.grad_color = LV_COLOR_BLACK;
	sb_style.body.border.color = LV_COLOR_WHITE;
	sb_style.body.border.width = 1;
	sb_style.body.radius = LV_RADIUS_CIRCLE;
	sb_style.body.opa = LV_OPA_60;
	sb_style.body.padding.right = 3;//垂直滚动条的宽度
	sb_style.body.padding.bottom = 3;//水平滚动条的宽度
	sb_style.body.padding.inner = 8;//滚动条距页面边框的距离
	//1.2 创建边缘半圆弧样式
	lv_style_copy(&edge_flash_style,&lv_style_plain);
	edge_flash_style.body.main_color = LV_COLOR_GRAY;
	edge_flash_style.body.grad_color = LV_COLOR_GRAY;
	edge_flash_style.body.opa = 150;//透明度

	//2.创建页面
	//2.1 创建page1页面对象
	page1 = lv_page_create(scr,NULL);
	lv_obj_set_size(page1, 200, 200);//设置页面的大小
	lv_obj_align(page1, NULL, LV_ALIGN_CENTER,0,0);//与屏幕居中对齐
	lv_page_set_sb_mode(page1,sb_mode);//LV_SB_MODE_AUTO是默认的滚动条模式
	lv_page_set_edge_flash(page1,true);//使能边缘半圆弧动画效果
	lv_page_set_style(page1,LV_PAGE_STYLE_SB,&sb_style);//设置滚动条的样式
	lv_page_set_style(page1,LV_PAGE_STYLE_EDGE_FLASH,&edge_flash_style);//设置边缘半圆弧样式
	//2.2 往page1页面中添加一个label1标签子对象
	lv_obj_t * label1 = lv_label_create(page1,NULL);//这里的父对象应该是page1
	lv_label_set_long_mode(label1, LV_LABEL_LONG_BREAK);//设置长本文模式
	lv_obj_set_width(label1,lv_page_get_fit_width(page1));//设置与page1页面的填充区域宽度相等
	lv_label_set_text(label1, "hello everyone! I'm Mu Yi. I'm very happy to learn little VGL with you." 
								"We are also honored to choose products from PRECHIN."
								"Let's swim together in the embedded ocean."
								"Our slogan is: open source sharing, common progress"
								"Please remember: Science and technology revitalize China, learning to change destiny!");
	//2.3 往page1页面中添加一个btn1按钮子对象
	btn1 = lv_btn_create(page1,NULL);//这里的父对象应该是page1
	lv_obj_set_size(btn1,80,50);
	lv_obj_align(btn1,label1,LV_ALIGN_OUT_RIGHT_MID,0,0);//设置与label1的对齐方式
	lv_obj_t * btn_label = lv_label_create(btn1,NULL);//给btn1按钮添加文本标题
	lv_label_set_text(btn_label,"Clean");
	lv_obj_set_event_cb(btn1,event_handler);//设置事件回调函数,当点击时清空page1内部的所有子对象

}

//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		lv_page_focus(page1,btn1,LV_ANIM_ON);//使btn1按钮处于可见状态
	}else if(key==KEY1_PRESS)
	{
		lv_page_scroll_ver(page1,-10);//让page1页面往下滚动
	}else if(key==KEY2_PRESS)
	{
		lv_page_scroll_hor(page1,-10);//让page1页面往右滚动
	}else if(key==KEY_UP_PRESS)
	{
		sb_mode++;
		if(sb_mode>LV_SB_MODE_UNHIDE)
			sb_mode = LV_SB_MODE_OFF;
		lv_page_set_sb_mode(page1,sb_mode);//设置滚动条的模式
	}
}


#ifndef __LV_PAGE_TEST_H__
#define __LV_PAGE_TEST_H__
#include "system.h"



//��������
void lv_page_test_start(void);
void key_handler(void);
#endif



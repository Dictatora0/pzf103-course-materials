#ifndef __LV_TABLE_TEST_H__
#define __LV_TABLE_TEST_H__
#include "system.h"



//��������
void lv_table_test_start(void);
void key_handler(void);
#endif



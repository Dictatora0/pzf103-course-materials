#include "lv_table_test.h"
#include "lvgl.h"
#include "key.h"

lv_style_t cell1_style;
lv_style_t cell2_style;
lv_style_t cell3_style;
lv_obj_t * table1;
bool is_cell_crop = false;//默认是使能文本自动换行功能的
bool is_cell_merge = false;//是否合并单元格,默认不合并
	
#define TABLE_COL_CNT   3   //表格的列数
#define TABLE_ROW_CNT   4   //表格的行数

//定义每一行单元格的文本内容
const char * const TABLE_CELL_VALUE[TABLE_ROW_CNT][TABLE_COL_CNT] = {
  {"Name","Work","Math"},//第一行,作为标题行
  {"Hello,PRECHIN","95","90"},//数据行
  {"Muyi","56","99"},//数据行
  {"Fish","88","93"}//数据行
};
//每一列的宽度
const uint16_t TABLE_COL_WIDTH[TABLE_COL_CNT] = {100,60,60};

//例程入口
void lv_table_test_start()
{
	uint16_t row,col;

	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

	//1.创建样式
	//1.1 创建第一种单元格样式,用来修饰普通数据单元格
	lv_style_copy(&cell1_style,&lv_style_plain);
	cell1_style.body.border.width = 1;
	cell1_style.body.border.color = LV_COLOR_BLACK;
	//1.2 创建第二种单元格样式,用来修饰标题行中的单元格
	lv_style_copy(&cell2_style,&lv_style_plain_color);
	cell2_style.body.border.width = 1;
	cell2_style.body.border.color = LV_COLOR_BLACK;
	cell2_style.body.main_color = LV_COLOR_SILVER;//银色的背景
	cell2_style.body.grad_color = LV_COLOR_SILVER;
	cell2_style.text.color = LV_COLOR_BLACK;
	//1.3 创建第三种单元格样式,用来修饰特殊的单元格,比如进行数据高亮显示等等
	lv_style_copy(&cell3_style,&lv_style_plain);
	cell3_style.body.border.width = 1;
	cell3_style.body.border.color = LV_COLOR_BLACK;
	cell3_style.text.color = LV_COLOR_RED;//文本颜色为红色,高亮显示

	//2.创建表格
	table1 = lv_table_create(scr,NULL);
	lv_table_set_col_cnt(table1,TABLE_COL_CNT);//设置表格的总列数
	lv_table_set_row_cnt(table1,TABLE_ROW_CNT);//设置表格的总行数
	//设置每一列的宽度以及标题行的文本对齐方式和单元格类型
	for(col=0;col<TABLE_COL_CNT;col++)
	{
		lv_table_set_col_width(table1,col,TABLE_COL_WIDTH[col]);//设置每一列的宽度
		lv_table_set_cell_align(table1,0,col,LV_LABEL_ALIGN_CENTER);//标题行的文本内容居中对齐
		lv_table_set_cell_type(table1,0,col,2);//设置为第二种单元格类型
	}
	lv_table_set_cell_type(table1,2,1,3);//给(2,1)单元格设置为第三种类型,具有红色高亮显示的外观
	//设置所有单元格的文本内容
	for(row=0;row<TABLE_ROW_CNT;row++)
	{
		for(col=0;col<TABLE_COL_CNT;col++)
		{
			lv_table_set_cell_value(table1,row,col,(const char*)TABLE_CELL_VALUE[row][col]);//设置文本内容
		}
	}
	lv_table_set_style(table1,LV_TABLE_STYLE_BG,&lv_style_transp_tight);//设置表格的背景样式,为透明
	lv_table_set_style(table1,LV_TABLE_STYLE_CELL1,&cell1_style);//设置第一种单元格的样式
	lv_table_set_style(table1,LV_TABLE_STYLE_CELL2,&cell2_style);//设置第二种单元格的样式
	lv_table_set_style(table1,LV_TABLE_STYLE_CELL3,&cell3_style);//设置第二种单元格的样式
	lv_obj_align(table1,NULL,LV_ALIGN_CENTER,0,0);//设置表格与屏幕居中对齐
}


//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(key==KEY0_PRESS)
	{
		is_cell_crop = !is_cell_crop;
		lv_table_set_cell_crop(table1,1,0,is_cell_crop);//设置(1,0)单元格是否禁止自动换行功能
		lv_obj_invalidate(table1);//得手动刷新table1表格
	}else if(key==KEY1_PRESS)
	{
		is_cell_merge = !is_cell_merge;
		lv_table_set_cell_merge_right(table1,3,0,is_cell_merge);//是否将(3,0)单元格和(3,1)单元格合并为一个单元格
	}else if(key==KEY_UP_PRESS)
	{
		lv_table_set_cell_value(table1,2,0,"Mu\nyi");//用\n转义字符进行手动换行
	}
}

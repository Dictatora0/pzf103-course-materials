#include "lv_win_test.h"
#include "lvgl.h"



lv_style_t bg_style;
lv_obj_t * title_btn;

//事件回调函数
void event_handler(lv_obj_t * obj,lv_event_t event)
{
  if(obj==title_btn)
  {
    if(event==LV_EVENT_RELEASED)
    {
      lv_obj_t * win = lv_win_get_from_btn(title_btn);//获取此控制按钮所在的窗体对象,其实就是win1对象
      lv_win_set_title(win,"a new title");//修改窗体标题
    }
  }
}

//例程入口
void lv_win_test_start()
{
  lv_obj_t *scr = lv_scr_act();//获取当前活跃的屏幕对象


  //1.创建背景样式
  lv_style_copy(&bg_style,&lv_style_plain);
  bg_style.body.border.width = 2;
  bg_style.body.border.color = LV_COLOR_MAKE(0x55,0x96,0xD8);

  //2.创建窗体对象
  lv_obj_t * win1 = lv_win_create(scr,NULL);
  lv_obj_set_size(win1,220,220);//设置窗体的大小
  lv_obj_align(win1,NULL,LV_ALIGN_CENTER,0,0);//与屏幕居中对齐
  lv_win_set_title(win1,"Win title");//设置窗体的标题
  lv_win_set_btn_size(win1,30);//设置控制按钮的大小
  lv_win_set_drag(win1,true);//使能拖拽功能
  lv_win_set_style(win1,LV_WIN_STYLE_BG,&bg_style);//设置背景样式

  //2.1 往窗体中添加一个控制按钮,用于关闭窗体
  lv_obj_t * close_btn = lv_win_add_btn(win1,LV_SYMBOL_CLOSE);
  //给控制按钮设置事件回调函数,lv_win_close_event_cb是littleVGL系统内部自定义的一个事件回调函数
  //专门用于关闭窗体的
  lv_obj_set_event_cb(close_btn,lv_win_close_event_cb);

  //2.2 再往窗体中添加一个控制按钮,用于修改窗体的标题
  title_btn = lv_win_add_btn(win1,LV_SYMBOL_SETTINGS);
  lv_obj_set_event_cb(title_btn,event_handler);

  //2.3 往窗体页面中添加一个长文本的标签子对象
  lv_obj_t * label1 = lv_label_create(win1,NULL);
  lv_label_set_text(label1, "This is the content of the window\n\n"
                       "You can add control buttons to\n"
                       "the window header\n\n"
                       "The content area becomes automatically\n"
                       "scrollable is it's large enough.\n\n"
                       " You can scroll the content\n"
                       "See the scroll bar on the right!");
	
	
}








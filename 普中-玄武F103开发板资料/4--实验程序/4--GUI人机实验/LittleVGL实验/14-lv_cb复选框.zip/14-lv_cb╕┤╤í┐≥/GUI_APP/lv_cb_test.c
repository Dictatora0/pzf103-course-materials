#include "lv_cb_test.h"
#include "lvgl.h"


lv_style_t cb_bg_style;
lv_obj_t * label1;

//事件回调函数
static void event_handler(lv_obj_t * obj, lv_event_t event)
{
	if(event == LV_EVENT_VALUE_CHANGED)
	{
		lv_label_set_text(label1,lv_cb_is_checked(obj)?"Checked":"Unchecked");
	}
}

//例程入口
void lv_cb_test_start()
{
	lv_obj_t * scr = lv_scr_act();//获取当前活跃的屏幕对象

	
	//1.创建背景样式
	lv_style_copy(&cb_bg_style,&lv_style_plain_color);
	//1.1 body字段是用来修饰背景的
	cb_bg_style.body.opa = LV_OPA_TRANSP;//设置背景透明
	//1.2 text字段是用来修饰内部右侧的文本
	cb_bg_style.text.letter_space = 3;//字符之间的距离
	cb_bg_style.text.color = LV_COLOR_RED;//设置文本的颜色

	//2.创建复选框
	lv_obj_t * cb1 = lv_cb_create(scr, NULL);
	lv_cb_set_text(cb1,"checkbox");//设置文本
	lv_obj_set_pos(cb1,40,40);//设置坐标
	//lv_obj_set_size(cb1,100,50);调用此接口来设置复选框的大小是无效的,因为复选框的大小是自适应的
	lv_cb_set_style(cb1,LV_CB_STYLE_BG,&cb_bg_style);//设置样式
	lv_cb_set_checked(cb1,false);//设置复选框没有被选中
	lv_obj_set_event_cb(cb1,event_handler);//设置事件回调函数

	//3.创建一个label来显示复选框的选中状态
	label1 = lv_label_create(scr,NULL);
	lv_label_set_text(label1,"Unchecked");
	lv_obj_align(label1,cb1,LV_ALIGN_OUT_BOTTOM_LEFT,0,40);
	lv_label_set_body_draw(label1,true);
	lv_label_set_style(label1,LV_LABEL_STYLE_MAIN,&lv_style_plain_color);
}

#include "events_test.h"
#include "lvgl.h"
#include "key.h"
#include <stdio.h>


#define USER_EVENT_START		20
#define USER_EVENT_1			(USER_EVENT_START+1) //用户自定义事件1

//构建一个用户自定义数据结构体,当然了,如果你的用户数据简单,可以不用结构体
typedef struct{
	char name[20];
	u8 age;
}USER_DATA;

USER_DATA user_data = {{"MUYI"},25};//初始化一下

lv_obj_t * btn1;

//事件回调函数
static void btn_event_cb(lv_obj_t * obj,lv_event_t event)
{
	if(event==LV_EVENT_PRESSED)
	{
		//对象被按下时触发,每次按下时只触发一次
		printf("LV_EVENT_PRESSED\r\n");
	}else if(event==LV_EVENT_PRESSING)
	{
		//对象正在被按下中,只要按下不放,就会一直被触发
		printf("LV_EVENT_PRESSING\r\n");
	}else if(event==LV_EVENT_PRESS_LOST)
	{
		//在按下的过程中,手指从对象的可视区域划出时被触发
		printf("LV_EVENT_PRESS_LOST\r\n");
	}else if(event==LV_EVENT_SHORT_CLICKED)
	{
		//在LV_INDEV_LONG_PRESS_TIME时间之前松手触发,如果是
		//在被拖拽的话,则不会被触发
		printf("LV_EVENT_SHORT_CLICKED\r\n");
	}else if(event==LV_EVENT_LONG_PRESSED)
	{
		//按下时长超过LV_INDEV_LONG_PRESS_TIME值时触发,
 		//只会触发一次,如果是在被拖拽的话,则不会被触发
		printf("LV_EVENT_LONG_PRESSED\r\n");
	}else if(event==LV_EVENT_LONG_PRESSED_REPEAT)
	{
		//在触发LV_EVENT_LONG_PRESSED事件之后,接
		//下来按下的时长每超过LV_INDEV_LONG_PRESS_REP_TIME值一次,就会被
		//触发一次,如果是在被拖拽的话,则不会被触发
		printf("LV_EVENT_LONG_PRESSED_REPEAT\r\n");
	}else if(event==LV_EVENT_CLICKED)
	{
		//只要松手了就会被触发,但是如果触发了LV_EVENT_PRESS_LOST
		//事件的话,那么此事件将不会被触发
		printf("LV_EVENT_CLICKED\r\n");
	}else if(event==LV_EVENT_RELEASED)
	{
		//和LV_EVENT_CLICKED事件一样,没啥区别,位于LV_EVENT_CLICKED事件之后触发
		printf("LV_EVENT_RELEASED\r\n");
	}else if(event==LV_EVENT_DRAG_BEGIN)
	{
		//拖拽开始时触发
		printf("LV_EVENT_DRAG_BEGIN\r\n");
	}else if(event==LV_EVENT_DRAG_END)
	{
		//拖拽结束时触发
		printf("LV_EVENT_DRAG_END\r\n");
	}else if(event==LV_EVENT_DRAG_THROW_BEGIN)
	{
		//拖拽漂移开始时触发
		printf("LV_EVENT_DRAG_THROW_BEGIN\r\n");
	}else if(event==LV_EVENT_REFRESH)
	{
		//可以说是留给用户使用的一种事件,用户只能通过lv_event_send
		//接口来手动发送触发此事件
		printf("LV_EVENT_REFRESH\r\n");
	}else if(event==LV_EVENT_DELETE)
	{
		//对象被删除时触发
		printf("LV_EVENT_DELETE\r\n");
	}else if(event==USER_EVENT_1)
	{
		//用户自定义事件1
		USER_DATA* data = (USER_DATA*)lv_event_get_data();//获取用户自定义数据
		printf("USER_EVENT_1,name:%s,age:%d\r\n",data->name,data->age);
	}
}

//例程入口函数
void events_test_start()
{
	lv_obj_t* scr = lv_scr_act();//获取当前活跃的屏幕对象

	//3.创建一个默认按钮,用来测试事件
	btn1 = lv_btn_create(scr, NULL);
	lv_obj_set_pos(btn1,20,20);//设置坐标
	lv_obj_set_size(btn1,150,50);//设置大小
	lv_obj_set_event_cb(btn1,btn_event_cb);//设置回调函数
	lv_obj_t* label = lv_label_create(btn1,NULL);//给btn1添加label子对象
	lv_label_set_text(label,"Click me");//设置文本
}

//按键处理
void key_handler()
{
	u8 key = KEY_Scan(0);
	
	if(btn1==NULL)
		return;
	if(key==KEY0_PRESS)
	{
		//手动发送事件
		//方式1:发送用户自定义事件,同时携带用户自定义数据
		lv_event_send(btn1,USER_EVENT_1,&user_data);
		//方式2:发送系统自带的事件,不携带用户自定义数据
		//这里主要是为了演示一下lv_event_send_func接口
		//lv_event_send_func(btn_event_cb,btn1,LV_EVENT_REFRESH,NULL);
	}else if(key==KEY1_PRESS)
	{
		//使能之后,主要是用来测试LV_EVENT_DRAG_BEGIN,LV_EVENT_DRAG_END,LV_EVENT_DRAG_THROW_BEGIN三个事件的
		lv_obj_set_drag(btn1,true);//使能拖拽功能
		lv_obj_set_drag_throw(btn1,true);//使能拖拽惯性漂移功能
	}else if(key==KEY2_PRESS)
	{
		//删除对象,主要是用来测试LV_EVENT_DELETE事件
		if(btn1)
		{
			lv_obj_del(btn1);
			btn1 = NULL;
		}
	}
}


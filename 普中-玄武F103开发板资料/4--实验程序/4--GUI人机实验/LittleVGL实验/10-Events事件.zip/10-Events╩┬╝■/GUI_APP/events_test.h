#ifndef __EVENTS_TEST_H__
#define __EVENTS_TEST_H__
#include "system.h"







//��������
void events_test_start(void);
void key_handler(void);
#endif


